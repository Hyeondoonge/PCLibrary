package Server;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

public class MainServer implements Runnable{
	
 private MainServerThread clients[] = new MainServerThread[50]; 
   private ServerSocket server = null;
   private Thread thread = null;
   private InputStream is = null;
   private OutputStream os = null;
   private Protocol protocol = null;
   private Socket socket = null;
   private SQL sql = null;
   private StringTokenizer st ;
   private String res;
   
   private int clientCount = 0;

   public MainServer(int port) {
	   try {
	         protocol = new Protocol();
	         sql = new SQL("127.0.0.1", "root", "Dtd0613~~");
	         // sql = new SQL("192.168.220.14");

	         System.out.println("Binding to port " + port + ", please wait  ...");
	         server = new ServerSocket(port);
	         System.out.println("Server started: " + server);
	         start();
	      } catch (IOException ioe) {
	         System.out.println("Can not bind to port " + port + ": " + ioe.getMessage());
	      }
	   }
   
   private void addThread(Socket socket) {
	      if (clientCount < clients.length) {
	         System.out.println("Client accepted: " + socket);
	         clients[clientCount] = new MainServerThread(this, socket);
	         try {
	            clients[clientCount].open(); // Stream open
	            clients[clientCount].start();
	            clientCount++;
	         } catch (IOException ioe) {
	            System.out.println("Error opening thread: " + ioe);
	         }
	      } else
	         System.out.println("Client refused: maximum " + clients.length + " reached.");
	   }
   
   public void run() {
	      while (thread != null) {
	         try {
	            System.out.println("Waiting for a client ...");
	            addThread(server.accept());
	         } catch (IOException ioe) {
	            System.out.println("Server accept error: " + ioe);
	            stop();
	         }
	      }
	   }

	   public void start() {
	      if (thread == null) {
	         thread = new Thread(this);
	         thread.start();
	      }
	   }

	   public synchronized void remove(int ID) {
	   }

	   public void stop() {
	      if (thread != null) {
	         thread.stop();
	         thread = null;
	      }
	   }
	   
   
   public synchronized void handle(OutputStream os, FileOutputStream fs, int ID, byte[] buf) throws IOException {

	      int packetType = buf[0]; // ���� �����Ϳ��� ��Ŷ Ÿ�� ����
	      protocol.setPacket(packetType, buf); // ��Ŷ Ÿ���� Protocol ��ü�� packet ��������� buf�� ����
	      switch (packetType) {
	  	
	         case Protocol.PT_EXIT: // ���α׷� ���� ����
	            protocol = new Protocol(Protocol.PT_EXIT);
	            os.write(protocol.getPacket());
	            System.out.println(protocol.getPacket()[0]);
	
	            break;
	            
	         case Protocol.PT_REQ_WINDOW: // 20
	      	   
	     	   	String str = "";
	     	   	String kindofOpen = protocol.getWindowNum();
	     	   	
	     	   	switch(kindofOpen) {
	     	   	
		     	   	case "1":
		     	   		
		     	   		break;
		     	   	}
		     	   	
		     	    protocol = new Protocol(Protocol.PT_RES_WINDOW);
		     	    protocol.setData(str);
		     	    os.write(protocol.getPacket());
	     	    
	     	    break;
	     	    
	         case Protocol.PT_REQ_LOGIN:
	        	 
	        	 	st = new StringTokenizer(protocol.getLogin(),"#");
					res = sql.doLogin(st.nextToken(), st.nextToken()); // id, pw
					

					protocol = new Protocol(Protocol.PT_RES_LOGIN);
					
					if(res != "") { // �α��� ����
						protocol.setLogincode("1");
						protocol.setUserInform(res);
					} 
					else { // �α��� ����
						protocol.setLogincode("2");
						System.out.print("�� ����~");
					}
			     	os.write(protocol.getPacket());
			     	
			     	break;
			     	
	         case Protocol.PT_REQ_SEARCHSCHOOL:
	        	 
	        	 st = new StringTokenizer(protocol.getSearchschool(),"#");
	        	 res = sql.searchSchool(st.nextToken()); // id, pw
	        	 
	        	 System.out.println(res);
	        	 
				 protocol = new Protocol(Protocol.PT_RES_SEARCHSCHOOL);
					
				 protocol.setSchools(res);
					
			     os.write(protocol.getPacket());
			     	
			     break;
			     	
	      	}
	      }

   public static void main(String[] args) {
      MainServer server = new MainServer(3000);
   }
} //////////// MAIN SERVER