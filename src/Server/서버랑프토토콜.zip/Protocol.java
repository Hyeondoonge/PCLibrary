package Server;

public class Protocol {
   public static final int PT_UNDEFINED = -1; // ���������� �����Ǿ� ���� ���� ���
   public static final int PT_EXIT = 0; // ���α׷� ����
   //�л�
   public static final int PT_REQ_WINDOW = 1;
   public static final int PT_RES_WINDOW = 2;
   public static final int PT_REQ_SEARCHSCHOOL = 3; // �б� ã��
   public static final int PT_RES_SEARCHSCHOOL = 4; 
   public static final int PT_REQ_CHECKDUPLICATE_ID = 5;// ���̵� �ߺ� üũ
   public static final int PT_RES_CHECKDUPLICATE_ID = 6;
   public static final int PT_REQ_LOGIN = 7; //�α���
   public static final int PT_RES_LOGIN = 8; // �α��� ����
   public static final int PT_REQ_CERTIFICATESTUDENT = 9; // �л� ���� 
   public static final int PT_RES_CERTIFICATESTUDENT = 10;
   public static final int PT_REQ_CHANGEDATA = 11; // ȸ������ ����
   public static final int PT_RES_CHANGEDATA = 12;
   public static final int PT_REQ_EXTENDAPPLY = 13; // ���� ��û
   public static final int PT_RES_EXTENDAPPLY = 14;
   public static final int PT_REQ_SORTED_PCLIST = 15; // ���� PC
   public static final int PT_RES_SORTED_PCLIST = 16;
   public static final int PT_REQ_PCAPPLY = 17; // pc ��û
   public static final int PT_RES_PCAPPLY = 18;
   public static final int PT_REQ_NOTE = 19; //�Խù�
   public static final int PT_RES_NOTE = 20;
   //������

   public static final int PT_REQ_REGISTERPC = 21; //pc ���
   public static final int PT_RES_REGISTERPC = 22;
   public static final int PT_REQ_MODIFYPC = 23; //pc ����
   public static final int PT_RES_MODIFYPC = 24;
   public static final int PT_REQ_DELETEPC = 25; //pc ����
   public static final int PT_RES_DELETEPC = 26;
   public static final int PT_REQ_RETURNMESSAGE = 27; // �޽��� ����
   public static final int PT_RES_RETURNMESSAGE = 28;
   //���
   public static final int PT_REQ_USERCONTROL = 29; //ȸ�� ����
   public static final int PT_RES_UESRCONTROL = 30;
   public static final int PT_REQ_SORTED_USERLIST = 31; //����� ���п� ���� ȸ�� ����Ʈ
   public static final int PT_RES_SORTED_USERLIST = 32;
   public static final int PT_REQ_USERINFORM = 33; // ����� ����
   public static final int PT_RES_USERINFORM = 34;
   public static final int PT_REQ_DROPUSER = 35; // ��������
   public static final int PT_RES_DROPUSSER = 36;
   public static final int PT_REQ_CERTIFICATEMG = 37; //���� ����
   public static final int PT_RES_CERTIFICATEMG = 38;
   public static final int PT_REQ_UPLOAD = 39; //�������� ���ε�
   public static final int PT_RES_UPLOAD = 40;
   public static final int PT_REQ_DELETENOTE = 41; //�Խù� ����
   public static final int PT_RES_DELETENOTE = 42;

   
   public static final int LEN_PROTOCOL_TYPE = 1;
   public static final int LEN_DATA = 5000; // �ִ� 5000����Ʈ
   public static final int LEN_LAST = 2;
   public static final int LEN_FRAG = 2;
   public static final int LEN_SEQNUM = 2;
   public static final int LEN_ID = 20;
   public static final int LEN_PASSWORD = 20;
   public static final int LEN_NAME = 30;
   public static final int LEN_NICKNAME = 20;
   public static final int LEN_USERCODE = 3;
   public static final int LEN_PHONENUM = 20;
   public static final int LEN_SCHOOL = 50;
   public static final int LEN_MAIL = 40;
   public static final int LEN_CODE = 2;
   
   public static final int LEN_WINDOW_NUMBER = 2; 
   
   protected int protocolType;
   private byte[] packet; // �������ݰ� �������� ��������� �Ǵ� ����Ʈ �迭

   public Protocol() { // ������
      this(PT_UNDEFINED);
   }

   public Protocol(int protocolType) { // ������
      this.protocolType = protocolType;
      getPacket(protocolType);
   }

   // �������� Ÿ�Կ� ���� ����Ʈ �迭 packet�� length�� �ٸ�
   public byte[] getPacket(int protocolType) {
      if (packet == null) {
         switch (protocolType) {
         case PT_UNDEFINED:
             packet = new byte[LEN_PROTOCOL_TYPE+ LEN_DATA];
             break;
         case PT_EXIT:
             packet = new byte[LEN_PROTOCOL_TYPE];
             break;
         case PT_REQ_WINDOW:
        	 packet = new byte[LEN_PROTOCOL_TYPE + LEN_WINDOW_NUMBER];
             break;
         case PT_RES_WINDOW:
        	 packet = new byte[LEN_PROTOCOL_TYPE + LEN_FRAG + LEN_LAST + LEN_SEQNUM + LEN_DATA];
             break;
         case PT_REQ_SEARCHSCHOOL:
        	 packet = new byte[LEN_PROTOCOL_TYPE + LEN_SCHOOL];
        	 break;
         case PT_RES_SEARCHSCHOOL:
        	 packet = new byte[LEN_PROTOCOL_TYPE + LEN_DATA];
        	 break;
         case PT_REQ_LOGIN:
        	 packet = new byte[LEN_PROTOCOL_TYPE + LEN_ID + LEN_PASSWORD];
        	 break;
         case PT_RES_LOGIN:
        	 packet = new byte[LEN_PROTOCOL_TYPE + LEN_CODE + LEN_ID + LEN_PASSWORD + LEN_NAME 
        	                   + LEN_NICKNAME + LEN_USERCODE + LEN_PHONENUM + LEN_SCHOOL + LEN_MAIL];
        	 break;
         } // end switch
      } // end if
      packet[0] = (byte) protocolType; // packet ����Ʈ �迭�� ù ��° ����Ʈ�� �������� Ÿ�� ����
      return packet;
   }
   
   public void setProtocolType(int protocolType) {
	      this.protocolType = protocolType;
	   }

	   public int getProtocolType() {
	      return protocolType;
	   }

	   public byte[] getPacket() {
	      return packet;
	   }

	   // Default �����ڷ� ������ �� Protocol Ŭ������ packet �����͸� �ٲٱ� ���� �޼���
	   public void setPacket(int pt, byte[] buf) {
	      packet = null;
	      packet = getPacket(pt);
	      protocolType = pt;
	      System.arraycopy(buf, 0, packet, 0, packet.length);
	   }
	   
	   public void setWindowNum(String num) {
		   System.arraycopy(num.trim().getBytes(), 0, packet, LEN_PROTOCOL_TYPE, num.trim().getBytes().length);
		      packet[LEN_PROTOCOL_TYPE + num.trim().getBytes().length] = '\0';
	   }
	   
	   public String getWindowNum() {
		   return new String(packet, LEN_PROTOCOL_TYPE, LEN_WINDOW_NUMBER).trim();
	   } 
	   
	   public void setLogin(String login) {
		   System.arraycopy(login.trim().getBytes(), 0, packet, LEN_PROTOCOL_TYPE, login.trim().getBytes().length);
		      packet[LEN_PROTOCOL_TYPE + login.trim().getBytes().length] = '\0';
	   }
	   
	   public String getLogin() {
		   return new String(packet, LEN_PROTOCOL_TYPE, LEN_ID + LEN_PASSWORD).trim();
	   } 
	   
	   public void setLogincode(String code) {
		   System.arraycopy(code.trim().getBytes(), 0, packet, LEN_PROTOCOL_TYPE, code.trim().getBytes().length);
		      packet[LEN_PROTOCOL_TYPE + code.trim().getBytes().length] = '\0';
	   }
	   
	   public String getLogincode() {
		   return new String(packet, LEN_PROTOCOL_TYPE, LEN_CODE).trim();
	   } 
	   
	   
	   public void setUserInform(String user) {
		   System.arraycopy(user.trim().getBytes(), 0, packet, LEN_PROTOCOL_TYPE + LEN_CODE, user.trim().getBytes().length);
		      packet[LEN_PROTOCOL_TYPE + LEN_CODE + user.trim().getBytes().length] = '\0';
	   }
	   
	   public String getUserInform() {
		   return new String(packet, LEN_PROTOCOL_TYPE + LEN_CODE, LEN_ID + LEN_PASSWORD + LEN_NAME 
                   + LEN_NICKNAME + LEN_USERCODE + LEN_PHONENUM + LEN_SCHOOL + LEN_MAIL).trim();
	   } 

	   public void setData(String data) {
		   System.arraycopy(data.trim().getBytes(), 0, packet, LEN_PROTOCOL_TYPE, data.trim().getBytes().length);
		      packet[LEN_PROTOCOL_TYPE + LEN_FRAG + LEN_LAST + LEN_SEQNUM + data.trim().getBytes().length] = '\0';
	   }
	   
	   public String getData() {
		   return new String(packet, LEN_PROTOCOL_TYPE + LEN_FRAG + LEN_LAST + LEN_SEQNUM, LEN_DATA).trim();
	   }
	   
	   public void setFrag(String frag) {
		   System.arraycopy(frag.trim().getBytes(), 0, packet, LEN_PROTOCOL_TYPE, frag.trim().getBytes().length);
		      packet[LEN_PROTOCOL_TYPE + frag.trim().getBytes().length] = '\0';
	   }
	   
	   public String getFrag() {
		   return new String(packet, LEN_PROTOCOL_TYPE, LEN_FRAG).trim();
	   } 
	   
	   
	   public void setLast(String islast) {
		   System.arraycopy(islast.trim().getBytes(), 0, packet, LEN_PROTOCOL_TYPE + LEN_PROTOCOL_TYPE + LEN_FRAG, islast.trim().getBytes().length);
		      packet[LEN_PROTOCOL_TYPE + LEN_FRAG + islast.trim().getBytes().length] = '\0';
	   }
	   
	   public String getLast() {
		   return new String(packet, LEN_PROTOCOL_TYPE + LEN_FRAG + LEN_LAST + LEN_SEQNUM, LEN_LAST).trim();
	   }

	   public void setSeq(String seq) {
		   System.arraycopy(seq.trim().getBytes(), 0, packet, LEN_PROTOCOL_TYPE + LEN_FRAG + LEN_LAST, seq.trim().getBytes().length);
		      packet[LEN_PROTOCOL_TYPE + LEN_FRAG + LEN_LAST + seq.trim().getBytes().length] = '\0';
	   }
	   
	   public String getSeq() {
		   return new String(packet, LEN_PROTOCOL_TYPE + LEN_FRAG + LEN_LAST, LEN_SEQNUM).trim();
	   } 
	   
	   public void setSearchschool(String sch) {
		   System.arraycopy(sch.trim().getBytes(), 0, packet, LEN_PROTOCOL_TYPE, sch.trim().getBytes().length);
		    packet[LEN_PROTOCOL_TYPE + sch.trim().getBytes().length] = '\0';
	   }
	   
	   public String getSearchschool() {
		   return new String(packet, LEN_PROTOCOL_TYPE, LEN_SCHOOL).trim();
	   } 
	   
	   public void setSchools(String sch) {
		   System.arraycopy(sch.trim().getBytes(), 0, packet, LEN_PROTOCOL_TYPE, sch.trim().getBytes().length);
		    packet[LEN_PROTOCOL_TYPE + sch.trim().getBytes().length] = '\0';
	   }
	   
	   public String getSchools() {
		   return new String(packet, LEN_PROTOCOL_TYPE, LEN_DATA).trim();
	   } 

}