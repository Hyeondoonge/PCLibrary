package Server;

import java.net.*;
import java.util.ArrayList;
import java.io.*;

public class MainServerThread extends Thread {
	
   private MainServer server = null;
   private Socket socket = null;
   private int ID = -1;
   private InputStream is = null;
   private OutputStream os = null;
   private FileOutputStream fs = null;
   private FileInputStream fis = null;
   //private User user = null;
   private int tempsize = 0;
   private int cnt = 0;
   private int a_cnt = 0;
   private int b_cnt = 0;
   private Protocol protocol = null;
   private String updownStudentNum = null;
   
   private File f = null;

   //���� �ٿ�ε� ����
   String filenameD = null;
    String filesizeD = null;
    String studentNumD = null;
    int cntD = 0; // �� ��° ����
    
    ArrayList<byte[]> dataD = new ArrayList<>();

   public MainServerThread(MainServer _server, Socket _socket) {
      super();
      server = _server;
      socket = _socket;
      ID = socket.getPort();
   }
   
   public void DNULL() {
      filenameD = null;
       filesizeD = null;
       studentNumD = null;
       cntD = 0; // �� ��° ����
       
       dataD = new ArrayList<>();
   }
   
   public String getUpdownStudentNum() {
      return updownStudentNum;
   }

   public int getTempSize() {
      return tempsize;
   }

   public void setTempSize(int tempsize) {
      this.tempsize = tempsize;
   }

   public void send(byte[] packet) {
      try {
         os.write(packet); 
         os.flush();
      } catch (IOException ioe) {
         System.out.println(ID + " ERROR sending: " + ioe.getMessage());
         stop();
      }
   }

   public void run() {
      System.out.println("Server Thread " + ID + " running.");
      byte[] buf = new byte[Protocol.LEN_DATA];
      try {
         while (true) {
            is.read(buf);
            protocol = new Protocol();
            protocol.setPacket(buf[0], buf);

            server.handle(os, fs, ID, buf);

         } // end while

      } catch (IOException ioe) {
         System.out.println(ID + " ERROR reading: " + ioe.getMessage());
         stop();
      }
   }
   
   private void setFileInfo(String studentNum){
        long fsize = 0;
        // filename�� DB table�� �����ؼ� ����.
        // filename = Select �̹������ from �������ܼ� where �й� = studentNum;
        filenameD = "packman.png";

        f = new File("C:\\tuber\\"+studentNum+".jpg"); // ���� ��ġ
        if(f.exists()){
            fsize = f.length();
        }
        filesizeD = Long.toString(fsize);
    }
   
   private void fileSplit(FileInputStream file) throws FileNotFoundException, IOException{
        int fsize = Integer.parseInt(filesizeD);
        
        dataD = new ArrayList();
        for(int i =0 ; i <= fsize / 2000; i++){ // 103358 byte -> 104�� 0~ 103
            dataD.add(new byte[2000]);
            file.read(dataD.get(i), 0, 2000);
        }

    }

   public void open() throws IOException {
      is = socket.getInputStream();
      os = socket.getOutputStream();
   }

   public void close() throws IOException {
      if (socket != null)
         socket.close();
      if (is != null)
         is.close();
      if (os != null)
         os.close();
   }
}