package Student;

public class PCinform {
	
	String manufacturer, ip, id, pw, cpu, gpu, ram;
	
	public PCinform(String manufacturer, String ip, String id, String pw,
			String cpu, String gpu, String ram) {
		
		this.manufacturer = manufacturer;
		this.ip = ip;
		this.id = id;
		this.cpu =cpu;
		this.gpu = gpu;
		this.pw = pw;
		this.ram = ram;
		
	}
	
	public String getManufacturer() {
		return manufacturer;
	}
	public String getIp() {
		return manufacturer;
	}
	public String getId() {
		return manufacturer;
	}
	public String getPw() {
		return manufacturer;
	}
	public String getCpu() {
		return manufacturer;
	}
	public String getGpu() {
		return manufacturer;
	}
	public String getRam() {
		return manufacturer;
	}
}
